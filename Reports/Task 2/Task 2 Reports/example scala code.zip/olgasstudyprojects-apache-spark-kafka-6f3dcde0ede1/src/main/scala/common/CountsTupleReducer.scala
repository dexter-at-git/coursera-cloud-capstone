package common

trait CountsTupleReducer {
  type DelayAndCounter = (Float, Int)

  def reduceIntCounts(counter1: (Int, Int), counter2 : (Int, Int)) = {
    (counter1._1 + counter2._1, counter1._2 + counter2._2)
  }

  def reduceDelays(delay1: DelayAndCounter, delay2: DelayAndCounter) = {
    (delay1._1 + delay2._1, delay1._2 + delay2._2)
  }
}