# AviationAnalytics
Fun with MapReduce, Hive, Pig, Storm and Cassandra

Airline data from 1987 - 2008
