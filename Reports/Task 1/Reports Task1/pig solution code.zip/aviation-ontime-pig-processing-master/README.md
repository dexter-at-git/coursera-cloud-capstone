# Cloud Computing Capstone 2015

## Pig scripts for aviation statistical processing
