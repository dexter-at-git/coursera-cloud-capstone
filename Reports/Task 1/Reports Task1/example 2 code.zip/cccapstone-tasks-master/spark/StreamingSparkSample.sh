#!/usr/bin/env bash

# Another terminate
# $ nc -lk 9999
/usr/local/spark/bin/spark-submit StreamingSparkSample.py localhost 9999
