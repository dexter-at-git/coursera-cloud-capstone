bash spark/spark-submit.sh spark/kafka_group1_1.py dnjplatbuild02:2181 cccapstone-group1-1
