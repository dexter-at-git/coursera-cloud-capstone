$ scp -r -i /data/hadoop/CCCapstone.pem ubuntu@ec2-54-86-48-166.compute-1.amazonaws.com:/mnt/aviation/airline_ontime /data/hadoop/aviation/
