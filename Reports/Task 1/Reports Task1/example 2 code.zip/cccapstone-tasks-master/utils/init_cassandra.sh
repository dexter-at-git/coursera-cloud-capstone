/usr/local/cassandra/bin/cqlsh 10.5.178.79 9042 -f utils/init_cassandra.cql
