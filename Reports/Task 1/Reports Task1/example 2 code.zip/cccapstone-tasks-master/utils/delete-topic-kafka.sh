bin/kafka-topics.sh --zookeeper 127.0.0.1:2181 --delete --topic someTopic
