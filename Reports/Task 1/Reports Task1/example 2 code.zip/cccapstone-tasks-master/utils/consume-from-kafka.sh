kafka-console-consumer.sh --zookeeper dnjplatbuild02:2181 --topic my-replicated-topic --from-beginning
