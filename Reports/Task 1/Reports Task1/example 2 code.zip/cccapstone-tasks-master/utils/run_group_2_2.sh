bash spark/spark-submit.sh spark/kafka_group2_2.py dnjplatbuild02:2181 cccapstone-group2-2
