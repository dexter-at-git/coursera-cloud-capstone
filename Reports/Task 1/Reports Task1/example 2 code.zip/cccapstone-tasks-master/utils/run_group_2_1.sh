bash spark/spark-submit.sh spark/kafka_group2_1.py dnjplatbuild02:2181 cccapstone-group2-1
