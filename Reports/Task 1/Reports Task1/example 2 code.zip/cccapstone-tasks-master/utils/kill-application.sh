#!/usr/bin/env bash

/usr/local/hadoop/bin/yarn application -kill $*
